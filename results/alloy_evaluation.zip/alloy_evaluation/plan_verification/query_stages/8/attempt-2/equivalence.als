open safety_protocol_core
open query_ext

pred ruleOriginal {
  some p: Patron, f: Facility |
    p in f.(QueryExt.entrance) and
    p.(QueryExt.cooler) = p and
    p.(QueryExt.containsOutsideFood) = 1 and
    p.(QueryExt.containsAlcohol) = 1
}

pred rulePrime {
  some p: Patron, f: Facility |
    p in f.(QueryExt.entrance) and
    p.(QueryExt.cooler) = p and
    p.(QueryExt.containsOutsideFood) = 1 and
    p.(QueryExt.containsAlcohol) = 1
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
