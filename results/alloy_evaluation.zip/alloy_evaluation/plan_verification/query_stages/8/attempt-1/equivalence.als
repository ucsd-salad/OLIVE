open safety_protocol_core

pred ruleOriginal {
  some p: Patron, f: Facility |
    p.onDeck = True and
    p.carriesContraband = True and
    p.inWater = none and
    some z: f.zones | z.depthInches = 0
}

pred rulePrime {
  some p: Patron, f: Facility, z: WaterZone |
    p.onDeck = True and
    p.carriesContraband = True and
    p.inWater = none and
    z in f.zones and
    z.depthInches = 0
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
