open safety_protocol_core

pred rule {
  some p: Patron, f: Facility, z: WaterZone |
    p.onDeck = True and
    p.carriesContraband = True and
    p.inWater = none and
    z in f.zones and
    z.depthInches = 0
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
