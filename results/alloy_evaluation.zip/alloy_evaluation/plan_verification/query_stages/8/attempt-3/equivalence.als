open safety_protocol_core

pred ruleOriginal {
  some p: Patron, f: Facility |
    p.onDeck = True and
    p.carriesContraband = True and
    p.age >= 0 and
    f.zones != none
}

pred rulePrime {
  some p: Patron, f: Facility |
    p.onDeck = True and
    p.carriesContraband = True and
    p.age >= 0 and
    some f.zones
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
