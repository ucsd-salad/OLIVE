open safety_protocol_core

pred rule {
  some p: Patron, f: Facility |
    p.onDeck = True and
    p.carriesContraband = True and
    p.age >= 0 and
    f.zones != none
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
