open safety_protocol_core
open query_ext

pred ruleOriginal {
  some p: Patron, f: Facility, lg: Lifeguard |
    p in QueryExt.outsideFoodOrDrink and
    p in QueryExt.alcoholicBeverage and
    p.carriesContraband = True and
    lg.onDuty = True and
    lg in f.zones.assignedGuard and
    QueryExt.outsideFoodAlcoholPermitted[f] = False and
    QueryExt.enforcementActionForContraband[lg] = True
}

pred rulePrime {
  some p: Patron, f: Facility, l: Lifeguard, z: WaterZone |
    p in QueryExt.outsideFoodOrDrink and
    p in QueryExt.alcoholicBeverage and
    p.carriesContraband = True and
    l.onDuty = True and
    z in f.zones and
    z.assignedGuard = l and
    QueryExt.outsideFoodAlcoholPermitted[f] = False and
    QueryExt.enforcementActionForContraband[l] = True
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
