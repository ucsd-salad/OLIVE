open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, f: Facility, l: Lifeguard, z: WaterZone |
    p in QueryExt.outsideFoodOrDrink and
    p in QueryExt.alcoholicBeverage and
    p.carriesContraband = True and
    l.onDuty = True and
    z in f.zones and
    z.assignedGuard = l and
    QueryExt.outsideFoodAlcoholPermitted[f] = False and
    QueryExt.enforcementActionForContraband[l] = True
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
