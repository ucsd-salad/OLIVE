open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, f: Facility, lg: Lifeguard |
    p in QueryExt.outsideFoodOrDrink and
    p in QueryExt.alcoholicBeverage and
    p.carriesContraband = True and
    lg.onDuty = True and
    lg in f.zones.assignedGuard and
    QueryExt.outsideFoodAlcoholPermitted[f] = False and
    QueryExt.enforcementActionForContraband[lg] = True
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
