open safety_protocol_core

pred rule {
  some m: Adult, c: Patron, s: Spa |
    m.age >= 18 and
    c.age = 1 and
    c.inWater = s and
    m.inWaterSupervising = True and
    c.chaperoneAdult = m and
    c.wearsUSCGLifeJacket = False and
    c.drowningStage = PassiveDrowning
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
