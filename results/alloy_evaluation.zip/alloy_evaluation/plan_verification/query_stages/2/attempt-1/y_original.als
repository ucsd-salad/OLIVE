open safety_protocol_core

pred rule {
  some mom: Adult, child: Patron, s: Spa |
    child.age = 1 and
    child.inWater = s and
    mom.inWaterSupervising = True and
    child.chaperoneAdult = mom and
    child.wearsUSCGLifeJacket = False and
    child.drowningStage = PassiveDrowning
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
