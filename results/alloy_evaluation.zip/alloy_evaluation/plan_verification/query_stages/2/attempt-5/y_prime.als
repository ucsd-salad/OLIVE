open safety_protocol_core
open query_ext

pred rule {
  some a: Adult, c: Patron, s: Spa |
    a.inWater = s and
    c.inWater = s and
    c.age = 1 and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = True and
    c.wearsUSCGLifeJacket = False and
    SpaSubmersion in c.currentBehaviors
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
