open safety_protocol_core
open query_ext

pred rule {
  some m: Adult, s: Spa, c: Patron |
    c.age = 1 and
    c.inWater = s and
    m.(QueryExt.adultInWater) = s and
    m.inWaterSupervising = True and
    m.withinArmsReachOfWard = True and
    c.wearsUSCGLifeJacket = False and
    SpaSubmersion in c.currentBehaviors
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
