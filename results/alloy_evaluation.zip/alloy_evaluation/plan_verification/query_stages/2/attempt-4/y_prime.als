open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, s: Spa, a: Adult |
    p.age = 1 and
    p.(QueryExt.patronAgeMonths) = 16 and
    p.inWater = s and
    a.inWaterSupervising = True and
    p.chaperoneAdult = a and
    s.(QueryExt.spaMinimumAge) > p.age and
    p.(QueryExt.submergedIn) = s and
    p.wearsUSCGLifeJacket = False
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
