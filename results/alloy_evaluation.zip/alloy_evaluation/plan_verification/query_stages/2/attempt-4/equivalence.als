open safety_protocol_core
open query_ext

pred ruleOriginal {
  some m: Patron, s: Spa, a: Adult |
    m.age = 1 and
    m.(QueryExt.patronAgeMonths) = 16 and
    m.inWater = s and
    a.inWaterSupervising = True and
    m.chaperoneAdult = a and
    s.(QueryExt.spaMinimumAge) > m.age and
    m.(QueryExt.submergedIn) = s and
    m.wearsUSCGLifeJacket = False
}

pred rulePrime {
  some p: Patron, s: Spa, a: Adult |
    p.age = 1 and
    p.(QueryExt.patronAgeMonths) = 16 and
    p.inWater = s and
    a.inWaterSupervising = True and
    p.chaperoneAdult = a and
    s.(QueryExt.spaMinimumAge) > p.age and
    p.(QueryExt.submergedIn) = s and
    p.wearsUSCGLifeJacket = False
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
