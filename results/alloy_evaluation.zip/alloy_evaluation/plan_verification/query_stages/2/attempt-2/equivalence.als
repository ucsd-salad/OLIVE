open safety_protocol_core
open query_ext

pred ruleOriginal {
  some m: Patron, s: Spa, a: Adult |
    m.age = 1 and
    m.inWater = s and
    a.inWaterSupervising = True and
    m.chaperoneAdult = a and
    m.wearsUSCGLifeJacket = False and
    m.(QueryExt.submergedIn) = s
}

pred rulePrime {
  some p: Patron, s: Spa, a: Adult |
    p.age = 1 and
    p.inWater = s and
    a.inWaterSupervising = True and
    p.chaperoneAdult = a and
    p.wearsUSCGLifeJacket = False and
    p.(QueryExt.submergedIn) = s
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
