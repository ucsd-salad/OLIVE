open safety_protocol_core
open query_ext

pred rule {
  some m: Patron, s: Spa, a: Adult |
    m.age = 1 and
    m.inWater = s and
    a.inWaterSupervising = True and
    m.chaperoneAdult = a and
    m.wearsUSCGLifeJacket = False and
    m.(QueryExt.submergedIn) = s
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
