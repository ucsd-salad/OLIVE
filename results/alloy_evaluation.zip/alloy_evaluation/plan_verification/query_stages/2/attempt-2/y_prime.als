open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, s: Spa, a: Adult |
    p.age = 1 and
    p.inWater = s and
    a.inWaterSupervising = True and
    p.chaperoneAdult = a and
    p.wearsUSCGLifeJacket = False and
    p.(QueryExt.submergedIn) = s
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
