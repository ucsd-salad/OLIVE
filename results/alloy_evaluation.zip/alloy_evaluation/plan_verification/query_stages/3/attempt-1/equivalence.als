open safety_protocol_core

pred ruleOriginal {
  some b: Patron, m: Adult, f: Adult, p: Facility |
    b.age < 12 and
    b.wearsUSCGLifeJacket = True and
    m.inWaterSupervising = True and
    b.chaperoneAdult = m and
    f != m and
    b.chaperoneAdult != f
}

pred rulePrime {
  some p: Patron, a1, a2: Adult, f: Facility |
    p.age < 12 and
    p.wearsUSCGLifeJacket = True and
    a1.inWaterSupervising = True and
    p.chaperoneAdult = a1 and
    a2 != a1 and
    p.chaperoneAdult != a2
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
