open safety_protocol_core

pred rule {
  some p: Patron, a1, a2: Adult, f: Facility |
    p.age < 12 and
    p.wearsUSCGLifeJacket = True and
    a1.inWaterSupervising = True and
    p.chaperoneAdult = a1 and
    a2 != a1 and
    p.chaperoneAdult != a2
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
