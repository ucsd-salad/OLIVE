open safety_protocol_core
open query_ext

pred ruleOriginal {
  some f: Facility, d: DiarrhealIncident |
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60 and
    f.(QueryExt.reopenTimeMinutes) = d.poolClosedHours
}

pred rulePrime {
  some f: Facility, d: DiarrhealIncident |
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60 and
    f.(QueryExt.reopenTimeMinutes) = d.poolClosedHours
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
