open safety_protocol_core
open query_ext

pred ruleOriginal {
  some f: Facility, d: DiarrhealIncident |
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60 and
    some p: Patron | p.inWater in f.zones
}

pred rulePrime {
  some f: Facility, d: DiarrhealIncident, p: Patron |
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60 and
    p.inWater in f.zones
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
