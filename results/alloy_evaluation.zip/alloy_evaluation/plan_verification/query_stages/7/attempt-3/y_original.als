open safety_protocol_core
open query_ext

pred rule {
  some f: Facility, d: DiarrhealIncident |
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60 and
    some p: Patron | p.inWater in f.zones
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
