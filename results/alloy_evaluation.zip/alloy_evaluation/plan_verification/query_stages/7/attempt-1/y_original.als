open safety_protocol_core

pred rule {
  some g: Patron, f: Facility, w: WaterZone, d: DiarrhealIncident |
    g.inWater = w and
    w in f.zones and
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
