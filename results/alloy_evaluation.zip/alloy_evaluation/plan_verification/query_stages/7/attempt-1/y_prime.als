open safety_protocol_core

pred rule {
  some p: Patron, f: Facility, z: WaterZone, d: DiarrhealIncident |
    p.inWater = z and
    z in f.zones and
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
