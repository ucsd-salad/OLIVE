open safety_protocol_core
open query_ext

pred ruleOriginal {
  some g: Patron, f: Facility, z: WaterZone, d: DiarrhealIncident |
    g.inWater = z and
    z in f.zones and
    z = f.(QueryExt.mainPool) and
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60
}

pred rulePrime {
  some p: Patron, f: Facility, z: WaterZone, d: DiarrhealIncident |
    p.inWater = z and
    z in f.zones and
    z = f.(QueryExt.mainPool) and
    f.activeBiohazardIncident = d and
    d.minutesSinceIncident = 60
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
