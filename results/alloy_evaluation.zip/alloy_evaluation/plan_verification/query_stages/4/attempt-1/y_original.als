open safety_protocol_core

pred rule {
  some f: Facility, a: Adult, s: Patron, g: Lifeguard |
    g in f.zones.assignedGuard and
    s.chaperoneAdult = a and
    s.hasGIIllnessWithin14Days = True and
    s.age < 18
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
