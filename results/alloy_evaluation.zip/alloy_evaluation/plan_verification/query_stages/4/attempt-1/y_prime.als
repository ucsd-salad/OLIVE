open safety_protocol_core

pred rule {
  some f: Facility, a: Adult, p: Patron, l: Lifeguard, z: WaterZone |
    z in f.zones and
    z.assignedGuard = l and
    p.chaperoneAdult = a and
    p.hasGIIllnessWithin14Days = True and
    p.age < 18
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
