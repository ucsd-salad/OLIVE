open safety_protocol_core

pred ruleOriginal {
  some f: Facility, a: Adult, s: Patron, g: Lifeguard |
    g in f.zones.assignedGuard and
    s.chaperoneAdult = a and
    s.hasGIIllnessWithin14Days = True and
    s.age < 18
}

pred rulePrime {
  some f: Facility, a: Adult, p: Patron, l: Lifeguard, z: WaterZone |
    z in f.zones and
    z.assignedGuard = l and
    p.chaperoneAdult = a and
    p.hasGIIllnessWithin14Days = True and
    p.age < 18
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
