open safety_protocol_core
open query_ext

pred ruleOriginal {
  some f: Facility, s: Patron, a: Adult |
    s.age < 18 and
    s.(QueryExt.isChildOf) = a and
    s.hasGIIllnessWithin14Days = True and
    s in QueryExt.feelsFineNow
}

pred rulePrime {
  some f: Facility, p: Patron, a: Adult |
    p.age < 18 and
    a = p.(QueryExt.isChildOf) and
    p.hasGIIllnessWithin14Days = True and
    p in QueryExt.feelsFineNow
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
