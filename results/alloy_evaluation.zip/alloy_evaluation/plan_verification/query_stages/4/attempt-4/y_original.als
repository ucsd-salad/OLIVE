open safety_protocol_core
open query_ext

pred rule {
  some f: Facility, s: Patron, a: Adult |
    s.age < 18 and
    a in s.chaperoneAdult and
    s.hasGIIllnessWithin14Days = True and
    s in QueryExt.feelsFineNow
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
