open safety_protocol_core
open query_ext

pred ruleOriginal {
  some f: Facility, s: Patron, a: Adult |
    s in f.zones.patronCount implies True = True
    and s.age < 18
    and a in Adult
    and s.(QueryExt.isChildOf) = a
    and s in QueryExt.feelsFineNow
    and s.hasGIIllnessWithin14Days = True
}

pred rulePrime {
  some f: Facility, p: Patron, a: Adult |
    p in f.zones.patronCount implies True = True
    and p.age < 18
    and a in Adult
    and a = p.(QueryExt.isChildOf)
    and p in QueryExt.feelsFineNow
    and p.hasGIIllnessWithin14Days = True
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
