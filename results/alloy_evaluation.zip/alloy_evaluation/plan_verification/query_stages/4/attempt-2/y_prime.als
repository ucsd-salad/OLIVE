open safety_protocol_core
open query_ext

pred rule {
  some f: Facility, p: Patron, a: Adult |
    p in f.zones.patronCount implies True = True
    and p.age < 18
    and a in Adult
    and a = p.(QueryExt.isChildOf)
    and p in QueryExt.feelsFineNow
    and p.hasGIIllnessWithin14Days = True
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
