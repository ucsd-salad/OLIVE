open safety_protocol_core
open query_ext

pred rule {
  some f: Facility, s: Patron, a: Adult |
    s in f.zones.patronCount implies True = True
    and s.age < 18
    and a in Adult
    and s.(QueryExt.isChildOf) = a
    and s in QueryExt.feelsFineNow
    and s.hasGIIllnessWithin14Days = True
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
