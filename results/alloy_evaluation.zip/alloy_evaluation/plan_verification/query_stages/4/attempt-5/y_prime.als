open safety_protocol_core
open query_ext

pred rule {
  some f: Facility, p: Patron, a: Adult |
    p.age < 18 and
    p.chaperoneAdult = a and
    p in QueryExt.feelsFineNow and
    p.hasGIIllnessWithin14Days = True
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
