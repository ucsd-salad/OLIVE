open safety_protocol_core

pred ruleOriginal {
  some p: Patron |
    p.age < 18 and
    p.onDeck = True and
    p.currentBehaviors = Hyperventilation and
    p.inWater in DeepZone
}

pred rulePrime {
  some p: Patron |
    p.age < 18 and
    p.onDeck = True and
    p.currentBehaviors = Hyperventilation and
    p.inWater in DeepZone
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
