open safety_protocol_core
open query_ext

pred ruleOriginal {
  some p: Patron, f: Facility |
    p.age < 18 and
    p.participatesInHighRiskActivity = True and
    p.currentBehaviors = Hyperventilation and
    p.inWater in f.zones and
    p.inWater in DeepZone and
    some lg: Lifeguard |
      lg.onDuty = True and
      lg.assignedZone = p.inWater and
      lg.inEAPResponse = True and
      p.(QueryExt.staffIntervention) = lg and
      p.(QueryExt.interventionResponse) = ProlongedBreathHolding and
      some c: Certification |
        c in lg.certifications and
        c in QueryExt.interventionAuthority
}

pred rulePrime {
  some p: Patron, f: Facility |
    p.age < 18 and
    p.participatesInHighRiskActivity = True and
    Hyperventilation in p.currentBehaviors and
    p.inWater in f.zones and
    p.inWater in DeepZone and
    (some lg: Lifeguard |
      lg.onDuty = True and
      lg.assignedZone = p.inWater and
      lg.inEAPResponse = True and
      p.(QueryExt.staffIntervention) = lg and
      p.(QueryExt.interventionResponse) = ProlongedBreathHolding and
      (some c: Certification |
        c in lg.certifications and
        c in QueryExt.interventionAuthority))
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
