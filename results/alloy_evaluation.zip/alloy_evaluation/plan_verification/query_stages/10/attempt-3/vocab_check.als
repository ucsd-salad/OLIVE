open safety_protocol_core
open query_ext

run Vocab {} for 5 but 9 Int
