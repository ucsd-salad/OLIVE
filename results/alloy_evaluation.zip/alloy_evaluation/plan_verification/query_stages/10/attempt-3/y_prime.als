open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, f: Facility |
    p.age < 18 and
    p.participatesInHighRiskActivity = True and
    Hyperventilation in p.currentBehaviors and
    p.inWater in f.zones and
    p.inWater in DeepZone and
    (some lg: Lifeguard |
      lg.onDuty = True and
      lg.assignedZone = p.inWater and
      lg.inEAPResponse = True and
      p.(QueryExt.staffIntervention) = lg and
      p.(QueryExt.interventionResponse) = ProlongedBreathHolding and
      (some c: Certification |
        c in lg.certifications and
        c in QueryExt.interventionAuthority))
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
