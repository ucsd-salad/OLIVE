open safety_protocol_core

pred ruleOriginal {
  some p: Patron |
    p.age < 18 and
    p.onDeck = True and
    p.inWater = none and
    Hyperventilation in p.currentBehaviors and
    ProlongedBreathHolding in p.currentBehaviors and
    p.drowningStage = none and
    p.wristband = none and
    p.inWaterBuddy = none and
    p.chaperoneAdult = none and
    p.medicalClearance = none and
    p.supplementaryWaiver = none and
    p.hasHighRiskMedicalCondition = none and
    p.participatesInHighRiskActivity = none and
    p.isRegisteredAthlete = none and
    p.strikes = 0 and
    p.inTimeOut = none and
    p.permanentBan = none and
    p.hasGIIllnessWithin14Days = none and
    p.hasOpenWounds = none and
    p.carriesContraband = none and
    p.wearsSwimDiaper = none and
    p.wearsUSCGLifeJacket = none and
    p.tookShowerWithSoap = none and
    p.highRiskCertifications = none and
    p.timeOutMinutesRemaining = 0 and
    p.armpitHeightInches = 0 and
    p.chestHeightInches = 0 and
    p.heightInches = 0 and
    p.weightLbsTen = 0
}

pred rulePrime {
  some p: Patron |
    p.age < 18 and
    p.onDeck = True and
    p.inWater = none and
    Hyperventilation in p.currentBehaviors and
    ProlongedBreathHolding in p.currentBehaviors and
    p.drowningStage = none and
    p.wristband = none and
    p.inWaterBuddy = none and
    p.chaperoneAdult = none and
    p.medicalClearance = none and
    p.supplementaryWaiver = none and
    p.hasHighRiskMedicalCondition = none and
    p.participatesInHighRiskActivity = none and
    p.isRegisteredAthlete = none and
    p.strikes = 0 and
    p.inTimeOut = none and
    p.permanentBan = none and
    p.hasGIIllnessWithin14Days = none and
    p.hasOpenWounds = none and
    p.carriesContraband = none and
    p.wearsSwimDiaper = none and
    p.wearsUSCGLifeJacket = none and
    p.tookShowerWithSoap = none and
    p.highRiskCertifications = none and
    p.timeOutMinutesRemaining = 0 and
    p.armpitHeightInches = 0 and
    p.chestHeightInches = 0 and
    p.heightInches = 0 and
    p.weightLbsTen = 0
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
