open safety_protocol_core

pred rule {
  some p: Patron, s: ShallowZone |
    p.age = 13 and
    p.inWater = s and
    DivingInShallowWater in p.currentBehaviors
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
