open safety_protocol_core

run Vocab {} for 5 but 9 Int
