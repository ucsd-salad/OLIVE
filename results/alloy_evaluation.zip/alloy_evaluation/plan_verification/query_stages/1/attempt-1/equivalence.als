open safety_protocol_core

pred ruleOriginal {
  some p: Patron, z: ShallowZone |
    p.age = 13 and
    p.inWater = z and
    DivingInShallowWater in p.currentBehaviors
}

pred rulePrime {
  some p: Patron, s: ShallowZone |
    p.age = 13 and
    p.inWater = s and
    DivingInShallowWater in p.currentBehaviors
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
