open safety_protocol_core
open query_ext

pred ruleOriginal {
  some p: Patron, d: DivingArea, f: Facility |
    p.wristband = Yellow and
    p.chestHeightInches > 0 and
    p.(QueryExt.passedDeepWaterTest) = False and
    d in f.zones and
    d.depthInches > 120 and
    d.hasDivingBoard = True and
    p.onDeck = True and
    some a: Adult |
      a in p.chaperoneAdult and
      a.withinArmsReachOfWard = True
}

pred rulePrime {
  some p: Patron, d: DivingArea, f: Facility, a: Adult |
    p.wristband = Yellow and
    p.chestHeightInches > 0 and
    p.(QueryExt.passedDeepWaterTest) = False and
    d in f.zones and
    d.depthInches > 120 and
    d.hasDivingBoard = True and
    p.onDeck = True and
    p.chaperoneAdult = a and
    a.withinArmsReachOfWard = True
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
