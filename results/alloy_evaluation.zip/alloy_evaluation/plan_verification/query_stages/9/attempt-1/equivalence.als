open safety_protocol_core

pred ruleOriginal {
  some p: Patron, d: DivingArea, f: Facility |
    p.wristband = Yellow and
    p.inWater = d and
    d in f.zones and
    d.depthInches > 120 and
    p.chestHeightInches < d.depthInches and
    p.armpitHeightInches < d.depthInches and
    some a: Adult | a in p.chaperoneAdult and
      a.withinArmsReachOfWard = False
}

pred rulePrime {
  some p: Patron, d: DivingArea, f: Facility, a: Adult |
    p.wristband = Yellow and
    p.inWater = d and
    d in f.zones and
    d.depthInches > 120 and
    p.chestHeightInches < d.depthInches and
    p.armpitHeightInches < d.depthInches and
    p.chaperoneAdult = a and
    a.withinArmsReachOfWard = False
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
