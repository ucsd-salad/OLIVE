open safety_protocol_core

pred rule {
  some p: Patron, d: DivingArea, f: Facility, a: Adult |
    p.wristband = Yellow and
    p.inWater = d and
    d in f.zones and
    d.depthInches > 120 and
    p.chestHeightInches < d.depthInches and
    p.armpitHeightInches < d.depthInches and
    p.chaperoneAdult = a and
    a.withinArmsReachOfWard = False
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
