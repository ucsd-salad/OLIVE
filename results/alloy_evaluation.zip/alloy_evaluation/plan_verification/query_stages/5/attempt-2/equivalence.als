open safety_protocol_core
open query_ext

pred ruleOriginal {
  some f: Facility, p: Patron |
    f.lightningDetected = False and
    f.lastThunderMinutesAgo = 30 and
    f.(QueryExt.deckClearanceOrdered) = True and
    p.(QueryExt.patronObjecting) = True
}

pred rulePrime {
  some f: Facility, p: Patron |
    f.lightningDetected = False and
    f.lastThunderMinutesAgo = 30 and
    f.(QueryExt.deckClearanceOrdered) = True and
    p.(QueryExt.patronObjecting) = True
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
