open safety_protocol_core

pred rule {
  some f: Facility, p: Patron |
    f.lightningDetected = False and
    f.lastThunderMinutesAgo = 30 and
    p.onDeck = True and
    p.inWater = none and
    p.wristband = none
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
