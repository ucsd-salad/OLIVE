open safety_protocol_core

pred ruleOriginal {
  some f: Facility, p: Patron |
    f.lightningDetected = False and
    f.lastThunderMinutesAgo = 30 and
    p.onDeck = True and
    p.inWater = none and
    p.wristband = none
}

pred rulePrime {
  some f: Facility, p: Patron |
    f.lightningDetected = False and
    f.lastThunderMinutesAgo = 30 and
    p.onDeck = True and
    p.inWater = none and
    p.wristband = none
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
