open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, g: Lifeguard, w: WavePool |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wristband = Red and
    p.wearsUSCGLifeJacket = False and
    p.chaperoneAdult = none and
    g.assignedZone = w and
    g.onDuty = True and
    QueryExt.attendantMustRequire[g] = p and
    QueryExt.attendantMustRequireAction[g] = p and
    QueryExt.requiredAction[p] = ProlongedBreathHolding and
    QueryExt.requiredLifeJacket[p] = True and
    QueryExt.requiredSupervision[p] = none
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
