open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, l: Lifeguard, w: WavePool |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wristband = Red and
    p.wearsUSCGLifeJacket = False and
    no p.chaperoneAdult and
    l.assignedZone = w and
    l.onDuty = True and
    l.(QueryExt.attendantMustRequire) = p and
    l.(QueryExt.attendantMustRequireAction) = p and
    p.(QueryExt.requiredAction) = ProlongedBreathHolding and
    p.(QueryExt.requiredLifeJacket) = True and
    no p.(QueryExt.requiredSupervision)
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
