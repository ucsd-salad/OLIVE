open safety_protocol_core
open query_ext

pred ruleOriginal {
  some p: Patron, g: Lifeguard, w: WavePool |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wristband = Red and
    p.wearsUSCGLifeJacket = False and
    p.chaperoneAdult = none and
    g.assignedZone = w and
    g.onDuty = True and
    QueryExt.attendantMustRequire[g] = p and
    QueryExt.attendantMustRequireAction[g] = p and
    QueryExt.requiredAction[p] = ProlongedBreathHolding and
    QueryExt.requiredLifeJacket[p] = True and
    QueryExt.requiredSupervision[p] = none
}

pred rulePrime {
  some p: Patron, l: Lifeguard, w: WavePool |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wristband = Red and
    p.wearsUSCGLifeJacket = False and
    no p.chaperoneAdult and
    l.assignedZone = w and
    l.onDuty = True and
    l.(QueryExt.attendantMustRequire) = p and
    l.(QueryExt.attendantMustRequireAction) = p and
    p.(QueryExt.requiredAction) = ProlongedBreathHolding and
    p.(QueryExt.requiredLifeJacket) = True and
    no p.(QueryExt.requiredSupervision)
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
