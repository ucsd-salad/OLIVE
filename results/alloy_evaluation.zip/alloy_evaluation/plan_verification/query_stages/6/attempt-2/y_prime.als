open safety_protocol_core
open query_ext

pred rule {
  some f: Facility, w: WavePool, p: Patron, a: Adult |
    w in f.zones and
    p.age = 9 and
    p.heightInches < 48 and
    p.(QueryExt.isStrongSwimmer) = False and
    p.(QueryExt.parentDeclinedLifeJacket) = True and
    a.(QueryExt.supervisesFromEdge) = True and
    p.chaperoneAdult = a and
    p.inWater = w
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
