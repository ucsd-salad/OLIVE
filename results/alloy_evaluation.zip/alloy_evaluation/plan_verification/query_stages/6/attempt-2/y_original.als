open safety_protocol_core
open query_ext

pred rule {
  some f: Facility, wp: WavePool, c: Patron, a: Adult |
    wp in f.zones and
    c.age = 9 and
    c.heightInches < 48 and
    c.(QueryExt.isStrongSwimmer) = False and
    c.(QueryExt.parentDeclinedLifeJacket) = True and
    a.(QueryExt.supervisesFromEdge) = True and
    c.chaperoneAdult = a and
    c.inWater = wp
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
