open safety_protocol_core
open query_ext

pred ruleOriginal {
  some f: Facility, wp: WavePool, c: Patron, a: Adult |
    wp in f.zones and
    c.age = 9 and
    c.heightInches < 48 and
    c.(QueryExt.isStrongSwimmer) = False and
    c.(QueryExt.parentDeclinedLifeJacket) = True and
    a.(QueryExt.supervisesFromEdge) = True and
    c.chaperoneAdult = a and
    c.inWater = wp
}

pred rulePrime {
  some f: Facility, w: WavePool, p: Patron, a: Adult |
    w in f.zones and
    p.age = 9 and
    p.heightInches < 48 and
    p.(QueryExt.isStrongSwimmer) = False and
    p.(QueryExt.parentDeclinedLifeJacket) = True and
    a.(QueryExt.supervisesFromEdge) = True and
    p.chaperoneAdult = a and
    p.inWater = w
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
