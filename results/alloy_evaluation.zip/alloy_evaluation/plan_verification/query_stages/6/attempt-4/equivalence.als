open safety_protocol_core
open query_ext

pred ruleOriginal {
  some w: WavePool, c: Patron, a: Adult, g: Lifeguard |
    c.age < 18 and
    c.heightInches < 48 and
    c.inWater = w and
    c.wearsUSCGLifeJacket = False and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = False and
    g.assignedZone = w and
    g.(QueryExt.attendantMustRequire) = c and
    g.(QueryExt.attendantMustRequireAction) = c and
    c.(QueryExt.requiredAction) = ProlongedBreathHolding
}

pred rulePrime {
  some wp: WavePool, p: Patron, a: Adult, lg: Lifeguard |
    p.age < 18 and
    p.heightInches < 48 and
    p.inWater = wp and
    p.wearsUSCGLifeJacket = False and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = False and
    lg.assignedZone = wp and
    lg.(QueryExt.attendantMustRequire) = p and
    lg.(QueryExt.attendantMustRequireAction) = p and
    p.(QueryExt.requiredAction) = ProlongedBreathHolding
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
