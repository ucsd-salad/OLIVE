open safety_protocol_core
open query_ext

pred rule {
  some w: WavePool, c: Patron, a: Adult, g: Lifeguard |
    c.age < 18 and
    c.heightInches < 48 and
    c.inWater = w and
    c.wearsUSCGLifeJacket = False and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = False and
    g.assignedZone = w and
    g.(QueryExt.attendantMustRequire) = c and
    g.(QueryExt.attendantMustRequireAction) = c and
    c.(QueryExt.requiredAction) = ProlongedBreathHolding
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
