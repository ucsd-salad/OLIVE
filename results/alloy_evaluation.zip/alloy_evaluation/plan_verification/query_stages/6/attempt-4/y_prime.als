open safety_protocol_core
open query_ext

pred rule {
  some wp: WavePool, p: Patron, a: Adult, lg: Lifeguard |
    p.age < 18 and
    p.heightInches < 48 and
    p.inWater = wp and
    p.wearsUSCGLifeJacket = False and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = False and
    lg.assignedZone = wp and
    lg.(QueryExt.attendantMustRequire) = p and
    lg.(QueryExt.attendantMustRequireAction) = p and
    p.(QueryExt.requiredAction) = ProlongedBreathHolding
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
