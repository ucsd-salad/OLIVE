open safety_protocol_core

pred ruleOriginal {
  some f: Facility, wp: WavePool, c: Patron, a: Adult |
    wp in f.zones and
    c.age < 18 and
    c.heightInches < 48 and
    c.chaperoneAdult = a and
    c.inWater = wp and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = False and
    c.wearsUSCGLifeJacket = False
}

pred rulePrime {
  some f: Facility, w: WavePool, p: Patron, a: Adult |
    w in f.zones and
    p.age < 18 and
    p.heightInches < 48 and
    p.chaperoneAdult = a and
    p.inWater = w and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = False and
    p.wearsUSCGLifeJacket = False
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
