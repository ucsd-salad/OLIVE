open safety_protocol_core

pred rule {
  some f: Facility, w: WavePool, p: Patron, a: Adult |
    w in f.zones and
    p.age < 18 and
    p.heightInches < 48 and
    p.chaperoneAdult = a and
    p.inWater = w and
    a.inWaterSupervising = True and
    a.withinArmsReachOfWard = False and
    p.wearsUSCGLifeJacket = False
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
