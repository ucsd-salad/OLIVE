open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, w: WavePool, l: Lifeguard, a: Adult |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wearsUSCGLifeJacket = False and
    p.chaperoneAdult = a and
    a.withinArmsReachOfWard = False and
    l.assignedZone = w and
    l.(QueryExt.attendantMustRequire) = p
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
