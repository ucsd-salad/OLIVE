open safety_protocol_core
open query_ext

pred rule {
  some p: Patron, w: WavePool, g: Lifeguard |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wearsUSCGLifeJacket = False and
    some a: Adult | p.chaperoneAdult = a and a.withinArmsReachOfWard = False and
    g.assignedZone = w and
    g.(QueryExt.attendantMustRequire) = p
}

run Satisfiable { rule } for 5 but 9 Int
run Refutable { not rule } for 5 but 9 Int
