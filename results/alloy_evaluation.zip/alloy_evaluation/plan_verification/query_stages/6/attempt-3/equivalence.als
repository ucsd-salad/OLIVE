open safety_protocol_core
open query_ext

pred ruleOriginal {
  some p: Patron, w: WavePool, g: Lifeguard |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wearsUSCGLifeJacket = False and
    some a: Adult | p.chaperoneAdult = a and a.withinArmsReachOfWard = False and
    g.assignedZone = w and
    g.(QueryExt.attendantMustRequire) = p
}

pred rulePrime {
  some p: Patron, w: WavePool, l: Lifeguard, a: Adult |
    p.age < 9 and
    p.heightInches < 48 and
    p.inWater = w and
    p.wearsUSCGLifeJacket = False and
    p.chaperoneAdult = a and
    a.withinArmsReachOfWard = False and
    l.assignedZone = w and
    l.(QueryExt.attendantMustRequire) = p
}

run Sanity {} for 5 but 9 Int
check OriginalImpliesPrime { ruleOriginal implies rulePrime } for 5 but 9 Int
check PrimeImpliesOriginal { rulePrime implies ruleOriginal } for 5 but 9 Int
