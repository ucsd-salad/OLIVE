module vocab

-- Vocabulary for the choking / swallowed-object domain. Every field records only
-- what the caller said or asked, never a clinical conclusion or an answer.
-- A rule must leave every unmentioned field unconstrained. In particular, do not
-- set an unmentioned field to `Unknown` or `No`.

enum Tri { Yes, No, Unknown }

enum AgeSaid {
  Baby,        -- "my baby", "the infant", "nine week-old"
  Child,       -- "my toddler", "my daughter", "the kid"
  Adult,       -- "my husband", "my father", "my mom"
  Unspecified
}

enum QuestionAsked {
  WhatToDo,          -- "what do I do?", "what should I do now?"
  WhetherFatal,      -- "can the person die?"
  WhetherConcerned   -- "should I still be worried?"
}

enum ItemSaid { Food, Coin, Button, Other }

enum TimeSaid { Now, AboutOneDay, MultipleDays }

sig Ctx {
  ageSaid             : one AgeSaid,
  -- This records the question itself, not its answer and not a recommended action.
  questionAsked       : one QuestionAsked,
  saidChoking         : one Tri,   -- the caller used the word "choking"
  eatingOrItemInMouth : one Tri,   -- was eating or had food in the mouth; not actual ingestion
  itemSaid            : one ItemSaid,
  itemStuckInThroat   : one Tri,   -- caller said food/an object is stuck in the throat
  attemptedSwallow    : one Tri,   -- tried to swallow; does not imply it was swallowed
  itemSwallowed       : one Tri,   -- actual ingestion; use this instead of inferring from eating
  pickedUpFromFloor   : one Tri,
  itemSeenInMouth     : one Tri,
  itemRecovered       : one Tri,   -- item was later found outside the person's body
  itemPassed          : one Tri,   -- item came out / passed through
  itemStillInside     : one Tri,   -- caller believes the item remains inside
  timeSaid            : one TimeSaid,
  actingNormal        : one Tri,   -- acting/feeling normal or recovered
  clutchingThroat     : one Tri,   -- grabbing at the throat or neck
  makingSound         : one Tri,   -- can talk, cry, or make any sound
  coughing            : one Tri,
  breathing           : one Tri,
  turnedBlue          : one Tri,
  responsive          : one Tri,   -- answers, reacts, has not passed out
  helpPresent         : one Tri    -- someone other than the casualty is there to act
}
