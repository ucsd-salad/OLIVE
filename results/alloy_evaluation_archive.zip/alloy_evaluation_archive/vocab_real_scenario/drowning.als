module vocab

-- Vocabulary for the drowning domain. Every field records only what the caller said
-- or asked, never a clinical conclusion or an answer. Leave every unmentioned field
-- unconstrained; do not set it to `Unknown` or `No` by default.
--
-- Alloy enum values share one namespace, so the Lean `TimeSaid.unspecified`
-- becomes `TimeUnspecified` to stay apart from `AgeSaid`'s `Unspecified`.

enum Tri { Yes, No, Unknown }

enum AgeSaid {
  Baby,        -- "1-year-old baby", infant
  Child,       -- "my son", "the kid", "my nephew"
  Adult,
  Unspecified
}

enum QuestionAsked {
  WhatToDo,                -- what action/measures should be taken
  WhetherConcerned,        -- "should I be worried/concerned?"
  WhySymptom,              -- asks why coughing or another symptom occurs
  AboutRecovery,           -- asks about recovery after inhaling water
  WhatWasDone,             -- asks what someone did after the event
  WhetherExpelWaterFirst   -- asks about expelling water before CPR
}

enum TimeSaid {
  Now,             -- happening as the caller speaks
  Earlier,         -- minutes or hours ago
  DayOrMore,       -- "it's 24 hours later"
  TimeUnspecified
}

sig Ctx {
  ageSaid                          : one AgeSaid,
  timeSaid                         : one TimeSaid,
  -- This records the question itself, not its answer or a recommended action.
  questionAsked                    : one QuestionAsked,
  nearDrowningMentioned            : one Tri,
  swimming                         : one Tri,
  fellIntoWater                    : one Tri,   -- fell/entered the water; does not imply going underwater
  wasSubmerged                     : one Tri,   -- explicitly went under or was underwater
  missingFromView                  : one Tri,   -- person was in sight and then could no longer be seen
  outOfWater                       : one Tri,   -- pulled out, rescued, got him out
  cannotSwim                       : one Tri,
  responsive                       : one Tri,   -- awake, talking, answers
  breathing                        : one Tri,
  heartbeat                        : one Tri,
  coughing                         : one Tri,
  swallowedWater                   : one Tri,   -- swallowed water; does not imply inhalation into lungs
  swallowedWaterMoreThanOnce       : one Tri,
  inhaledWater                     : one Tri,   -- caller said water was breathed/inhaled into the lungs
  symptomsPresent                  : one Tri,   -- caller explicitly reports symptoms present or absent
  seemsRecovered                   : one Tri,   -- woke up, seems okay now
  lungsBelievedFullOfWater         : one Tri,
  cprMentioned                     : one Tri,
  rescueBreathsMentioned           : one Tri,
  believesRescueBreathsIneffective : one Tri
}
