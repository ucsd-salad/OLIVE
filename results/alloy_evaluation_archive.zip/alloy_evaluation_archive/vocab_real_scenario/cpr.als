module vocab

-- Vocabulary for the CPR domain. Every field records only what the caller said or
-- asked, never a clinical conclusion or an answer. Leave every unmentioned field
-- unconstrained; do not set it to `Unknown`, `No`, or `NoEvent` by default.
--
-- Alloy enum values share one namespace and `none` is a keyword, so the Lean
-- `PrecedingEvent.none` / `.unknown` become `NoEvent` / `UnknownEvent`.

enum Tri { Yes, No, Unknown }

enum PrecedingEvent { Choking, Drowning, NoEvent, UnknownEvent }

sig Ctx {
  -- Question fields record the caller's question, not the correct response.
  asksWhetherCPR                   : one Tri,
  asksWhetherToKeepCheckingPulse   : one Tri,
  asksWhatRespondersDo             : one Tri,
  asksWhetherBreathingWithoutPulse : one Tri,
  asksWhyCPR                       : one Tri,
  asksForHelp                      : one Tri,
  nursingHome                      : one Tri,
  adultSaid                        : one Tri,
  fell                             : one Tri,
  foundDown              : one Tri,   -- collapsed, fainted, passed out, found on the floor
  responsive             : one Tri,   -- answers, reacts, wakes up
  breathing              : one Tri,   -- the caller said the person is breathing
  troubleBreathing       : one Tri,
  breathingNormal        : one Tri,   -- the caller called that breathing normal, regular, quiet
  gasping                : one Tri,   -- caller explicitly reports snoring, gurgling, or gasping
  breathingPauses        : one Tri,   -- breathing happens intermittently and then stops/pauses
  pausesGettingLonger    : one Tri,
  fluidSound             : one Tri,   -- fluid/gurgling sound reported while breathing
  turnedBlue             : one Tri,
  pulseFelt              : one Tri,
  pulseFaint             : one Tri,
  warmSkin               : one Tri,
  aedNearby              : one Tri,
  priorAngioplasty       : one Tri,
  cardiacArrestMentioned : one Tri,
  emtMentioned           : one Tri,
  precededBy             : one PrecedingEvent
}
